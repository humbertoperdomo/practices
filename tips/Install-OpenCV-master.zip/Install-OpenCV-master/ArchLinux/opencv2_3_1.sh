pacman -S python2-numpy
pacman -S opencv 2.3.1_a-4
