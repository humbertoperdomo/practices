sudo apt-get install libopencv-*
sudo apt-get install python-opencv
sudo apt-get install python-numpy
